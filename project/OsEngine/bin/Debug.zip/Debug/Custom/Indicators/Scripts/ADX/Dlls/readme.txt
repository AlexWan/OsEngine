ENG
If Your script robot or indicator needs to load additional libraries, 
You need to create it in a separate folder and make a subfolder of the Dlls in this folder,
where you can put all the necessary builds. The compiler will load them automatically when compiling the robot or indicator


RUS
Если Ваш скриптовый робот или индикатор нуждается в подгрузке дополнительных библиотек, 
Вам нужно создать его в отдельной папке и в этой папке сделать подпапку Dlls,
в которую сможете положить все нужные сборки. Компилятор их автоматически подгрузит при компиляции робота или индикатора